//
//  ChUI.h
//  ChannelizeUI
//
//  Created by Ashish-BigStep on 3/25/20.
//  Copyright © 2020 Channelize. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ChUI.
FOUNDATION_EXPORT double ChannelizeUIVersionNumber;

//! Project version string for ChUI.
FOUNDATION_EXPORT const unsigned char ChannelizeUIVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ChannelizeUI/PublicHeader.h>


